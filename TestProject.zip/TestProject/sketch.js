let x1 = random(0,width);
let y1 = random(0,height);
let x2 = random(0,width);
let y2 = random(0,height);

function setup(){
createCanvas(windowWidth,windowHeight);
background(150,150,150);
// making my central shape
let rcol = random(0,255);
let gcol = random(0,255);
let bcol = random(0,255);

fill(rcol,gcol,bcol);
noStroke();
circle(width/2,height/2,500);


}

function draw(){

//making variables for moving my shape
if(mouseIsPressed){
  rect(random(x1,y1,x2,y2));
} else {
  circle(width/2,height/2, 500)
}





}
